#!/bin/bash

sudo apt-get update &&
    apt-get install -y software-properties-common
    apt-apt-repository -y ppp:etherum/ethereum ;

add-apt-repository -y ppa:ethereum/ethereum-dev
sudo apt-get update;

apt-get install -y ethereum solc

#Get first bloc content
bloc=$(cat ./bloc.json);

#works on Debian 8
cd /etc/apt/source.d/
#Error catching @n1c0

#todo
geth --datadir ./noeud1 --networkid "3" init bloc.json
geth --datadir ./noeud1 --networkid="3" account new
geth --datadir ./noeud2 --networkid "3" init bloc.json
geth --datadir ./noeud2 --networkid="3" account new
geth --datadir ./noeud3 --networkid "3" init bloc.json
geth --datadir ./noeud3 --networkid "3" init bloc.json
geth --datadir ./noeud4 --networkid="3" account new
geth --datadir ./noeud4 --networkid="3" account new
#-->todo

geth --datadir ./noeud1 --networkid="3" --port="1234" console &
geth --datadir ./noeud2 --networkid="3" --port="1234" console &
geth --datadir ./noeud3 --networkid="3" --port="1234" console &
geth --datadir ./noeud4 --networkid="3" --port="1234" console &

wait
echo "All complete"
wait
echo "Connect geth console"



